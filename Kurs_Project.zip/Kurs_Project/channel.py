import shutil
import os
from random import randint
from time import *
from send_data import *


def userlist():
    users = {'mike' : '1',
             'ivan' : '2',
             'vovachuma' : '3'}
    return users


def findsendpath(user, to):
    userlist()
    # sender =  #TODO iter by dict
    # rcver = #Todo iter by dict
    conadd = sender + 'to' + rcver
    return conadd, sender, rcver


def filesend(user, to, source):
    with open(source, 'rb') as fstream:
        byte = fstream.read()
        b = bytearray(byte)
        string = ''.join(map(bin, b))
        print(string)
        print(string.split('b'))

        # strk = b''.join(string)
        strk = bytearray(string.encode('utf-8'))
        print(strk)
        send_data('1to3', strk)

        # for n in string:


    #todo call in Ivan
    # findsendpath(user, to)
    # if not os.path.exists(os.path.basename(user)):
    #     os.makedirs(os.path.basename(user))
    if not os.path.exists(os.path.basename('ab_' + to)):
        os.makedirs(os.path.basename('ab_' + to))
    endpath = os.path.dirname(os.path.abspath(__file__)) + '/ab_' + to
    filec(source, endpath)
    print('done')
    return 0


def filec(source, endpath):
    sleep(randint(5, 15))
    shutil.copy2(source, endpath)
    print('Send complete, no errors')

# def filercv(string):
#     with open('rcv.txt', 'wb') as fstream:
#         fstream.write(string)

# CODING AND DECODING
def Code(string, encode):
        if string!="":
            return string+Xor(string,bin(int(string,2) << 3)[2:].zfill(encode))
        else:
            return ""


def Xor(string, info, *args):
    temp_div = ""
    temp = ""
    if len(args) == 1:
        temp_div = "1011"
        temp = args[0]
    elif 3 > len(args) > 1:
        temp = args[0]
        temp_div = args[1]
    else: assert AttributeError, "AttributeError in func.Xor"
    while(True):
        temp = bin(int(temp[:info],2)^int(temp_div,2))[2:] + temp[info:]
        need = temp.find("1")
        if len(temp) < info:
            return temp.zfill(info-1)
        temp = temp[need:]


def Code_all(string, encode):
    result=""
    for i in range(len(string)/encode):
        result=result+Code(string[encode*i:encode*i+encode], encode)
    return result


def Decode(string, encode, info):
        result=""
        for i in range(len(string)/encode):
                sub_=str(string[encode*i:encode*i+encode])
                sub_ = Transform(sub_, encode)
                result = result + str(sub_)[0:info]
                '''
                if sub_ in cicle_codes and len(sub_)>0:
                    result=result+sub_[0:4]
                else:
                    return False
                '''
        return result


def Transform(sub_, encode):
    msg = ""
    synd = (Xor(sub_, bin(int(sub_, 2))))
    if synd in Syndrome_:
        sub_int = 0
        for i in range(encode):
            sub_int = sub_int + int(sub_[i])*(2**((encode-1)-i))
        print('decoded')
        print(bin(int((Syndrome_.get(synd)))^int(sub_int))[2:])
        return msg + bin(int((Syndrome_.get(synd)))^int(sub_int))[2:]
    else:
        return sub_

# packet constructor
def constructor(codedstr, command):
# start packet format
    packet = '11111111'
    stop = '00001111'

    commands = {
        'ack': '00000111',
        'noack': '00000110',
        'link': '00000001',
        'unlink': '00000010',
        'norec': '00000100',
        'hed': '00000011',
        'info': '00000000',
    }

    packet += commands[usrcommand]
    packet += data
    packet += stop
    return packet

def fnames():
    count = 0
    userlist = os.listdir(os.getcwd())
    for n in userlist:
        if n[:3] == 'ab_':
            count+=1

    return count

def get_users():
    list_users = []
    users = os.listdir(os.getcwd())
    for n in users:
        if n[:3] == 'ab_':
            list_users.append(n.split('ab_')[1])
    print(list_users)
    return list_users

