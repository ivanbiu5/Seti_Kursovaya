from tkinter import *
import os.path
import shutil
from tkinter.messagebox import *
from tkinter.filedialog import *
from tkinter import filedialog
from uuid import getnode as get_mac
from channel import *

root=Tk()

root.mainloop()