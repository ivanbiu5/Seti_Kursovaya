from tkinter import *
import os.path

main_interface_title = Tk()
main_interface_title.title('User interface')
something=False


def Enter_Username():#функция ввода имени пользователя
    invalid_symbols = '*|:"<>?/'
    user_name = User_Name_Entry.get()
    flag_username = user_name
    if 18 < len(user_name):
        print('Invalid lenght.')
        flag_username = False
    for i in invalid_symbols:
        if i in user_name:
           print('Invalid syntax.')
           flag_username = False
           break
    if flag_username == True and len(user_name)!=0:
        print('User',user_name,'connected.')
    if len(user_name) == 0:
        flag_username = FalsChoose_Fe
        print('User name is too short.')

def Choose_File():
    file_path = os.path.normpath(File_Path_Entry.get())
    if os.path.exists(file_path) == True and os.path.isdir(file_path) == False:
        print("It's file. You input correct path.")
        print(file_path)
    else:
        print("It's not a file or input is not correct.")
        file_path = None

def Choose_COM1():
    COMnum_Flag = 'COM1'
    print(COMnum_Flag)
def Choose_COM2():
    COMnum_Flag = 'COM2'
    print(COMnum_Flag)
def Choose_COM3():
    COMnum_Flag = 'COM3'
    print(COMnum_Flag)

def Choose_Reciever():
    return 0

def Choose_CodeType_74():
    CodeType_Flag = '[7,4]'
    print(CodeType_Flag)

def Choose_CodeType_1511():
    CodeType_Flag = '[15,11]'
    print(CodeType_Flag)

def Choose_COMspeed():
    print('speedxui')

def Information():#вывод информации
    info_interface = Tk()
    info_interface.title('Information')
    info='Some useless information :).'
    Programm_info = Label(info_interface, text=info)
    Programm_info.pack()

def Disconnect_User():#функция отключения пользователя
    flag_username = User_Name_Entry.get()
    if len(flag_username) != 0:
        flag_username = False
        print('User '+ User_Name_Entry.get() +' disconnected.')
    else:
        print("You're not connected")

def Send_File():#отправка файла
    return Enter_Username(), Choose_File()

def Exit_Programm():
    main_interface_title.quit()


def Recieve_File(file_name, file):
    recieve_interface = Tk()
    recieve_interface.title('New file')
    File_Name_Label = Label(
        recieve_interface, text='Имя файла: '+file_name)
    File_Name_Label.grid(
        row=0, column=0)
    Open_File_Button = Button(
        recieve_interface, text='Сохранить файл', bg='white', fg='green')
    Open_File_Button.grid(
        row=0, column=1)
def Save_New_File():
    return 0

file_name = 'Kek'
file=1
if something == True:
    Recieve_File(file_name, file)


User_Name_Label = Label(
    main_interface_title, text='Имя пользователя:')
User_Name_Label.grid(
    row=0, column=0)
User_Name_Entry = Entry(
    main_interface_title, width=30)
User_Name_Entry.grid(
    row=0, column=1)


File_Path_Label = Label(
    main_interface_title, text='Путь файла:')
File_Path_Label.grid(
    row=1, column=0)
File_Path_Entry = Entry(
    main_interface_title, width=30)
File_Path_Entry.grid(
    row=1, column=1)


COM_Num_Label = Label(
    main_interface_title, text='Выберите COM порт:')
COM_Num_Label.grid(
    row=2, column=0)
COMNum_CheckButton = Checkbutton(
    main_interface_title, text='COM1',
    state=ACTIVE, command=Choose_COM1
).grid(row=2, column=1)
COMNum_CheckButton = Checkbutton(
    main_interface_title, text='COM2',
    state=ACTIVE, command=Choose_COM2
).grid(row=3, column=1)
COMNum_CheckButton = Checkbutton(
    main_interface_title, text='COM3',
    state=ACTIVE, command=Choose_COM3
).grid(row=4, column=1)


Reciever_Label = Label(
    main_interface_title, text='Имя получателя:')
Reciever_Label.grid(
    row=5, column=0)
Reciever_Entry = Entry(
    main_interface_title, width=30)
Reciever_Entry.grid(
    row=5, column=1)


CodeType_Label = Label(
    main_interface_title, text='Тип кодировки:')
CodeType_Label.grid(
    row=6, column=0)
CodeType_CheckButton = Checkbutton(
    main_interface_title, text='[7,4]',
    state=ACTIVE, command=Choose_CodeType_74
).grid(row=6, column=1)
CodeType_CheckButton = Checkbutton(
    main_interface_title, text='[15,11]',
    state=ACTIVE, command=Choose_CodeType_1511
).grid(row=7, column=1)


COM_Speed_Label = Label(
    main_interface_title, text='Скорость порта:')
COM_Speed_Label.grid(
    row=8, column=0)
COM_Speed_CheckButton = Checkbutton(
    main_interface_title, text='150bit/s',
    state=ACTIVE, command=Choose_COMspeed
).grid(row=8, column=1)
COM_Speed_CheckButton = Checkbutton(
    main_interface_title, text='600bit/s',
    state=ACTIVE, command=Choose_COMspeed
).grid(row=9, column=1)
COM_Speed_CheckButton = Checkbutton(
    main_interface_title, text='2400bit/s',
    state=ACTIVE, command=Choose_COMspeed
).grid(row=10, column=1)
COM_Speed_CheckButton = Checkbutton(
    main_interface_title, text='9600bit/s',
    state=ACTIVE, command=Choose_COMspeed
).grid(row=11, column=1)
COM_Speed_CheckButton = Checkbutton(
    main_interface_title, text='38400bit/s',
    state=ACTIVE, command=Choose_COMspeed
).grid(row=12, column=1)


button_information = Button(
    main_interface_title, text='Информация о приложении', bg='white', fg='green', command=Information)
button_information.grid(
    row=13, column=1)


button_send_file = Button(
    main_interface_title, text='Отправить файл', bg='white', fg='green', command=Send_File)
button_send_file.grid(
    row=14, column=1)


button_disconnect = Button(
    main_interface_title, text='Отключиться от сети', bg='white', fg='green', command=Disconnect_User)
button_disconnect.grid(
    row=15, column=1)

button_quit = Button(
    main_interface_title, text='Выход', bg='white', fg='green', command=Exit_Programm
).grid(row=16, column=1)


main_interface_title.mainloop()

# '''
# os.path.split(path)
# Параметры:	path (str) – путь к файлу
# Возвращает кортеж из пары строк - (путь к родителской папке, название файла).
#
# >>> os.path.split('c:\\system\\apps\\Python\\Python.app')
# ('c:\\system\\apps\\Python\\', 'Python.app')'''
