from port import comp1_in,comp1_out,comp2_in,comp2_out,comp3_in,comp3_out,pravila
import time
global NULL = b'00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000'
#  Функция отправляющая ACK, NoACK

def send_ack(to,bool):
    ack = b'11111111 00000111' + NULL + b'00001111'
    noack = b'11111111 00000110' + NULL + b'00001111'
    ack_data = b''

    if bool:
        for i,com in enumerate(pravila[to]):

            if i/2 == 1 or i == 0:
                com.isOpen()
                com.write(ack)

            if i/2 != 1 and i != 0:
                com.isOpen()
                print(com.in_waiting)
                ack_data = com.read(16)
                print(ack_data,com.port)

            return ack_data

    else:
        for i, com in enumerate(pravila[to]):

            if i / 2 == 1 or i == 0:
                com.isOpen()
                com.write(noack)

            if i / 2 != 1 and i != 0:
                com.isOpen()
                print(com.in_waiting)
                ack_data = com.read(16)
                print(ack_data, com.port)

            return ack_data

